# Single-Shot-Object-Detection-Updated
### From the Udemy Course on Open-CV by Hadelin de Ponteves

This code includes the updated SSD Class for the Latest PyTorch Support.
The function detection.py has been updated to make it compatible for SSD class and latest PyTorch Version.

#### Clone the Code and replace the existing SSD.py file and detect.py file (within layers/functions) with the updated ones if you have latest PyTorch Version 


